import adt.queue.CircularQueue;
import adt.queue.QueueOverflowException;
import adt.queue.QueueUnderflowException;

public class Main {

	public static void main(String[] args) throws QueueOverflowException, QueueUnderflowException {
		CircularQueue fila = new CircularQueue<Integer>(5);
		
		fila.enqueue(1);
		fila.enqueue(2);
		fila.dequeue();
		fila.dequeue();
		fila.enqueue(8);
		fila.enqueue(10);
		fila.dequeue();
		fila.isEmpty();

	}

}
